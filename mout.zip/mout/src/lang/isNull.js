define(function () {
    /**
     */
    function isNull(val){
        return val === null;
    }
    return isNull;
});

