/**
 * @constant Minimum 32-bit signed integer value (-2^31).
 */
define(function(){
    return -2147483648;
});
