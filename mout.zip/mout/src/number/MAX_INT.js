/**
 * @constant Maximum 32-bit signed integer value. (2^31 - 1)
 */
define(function(){
    return 2147483647;
});
