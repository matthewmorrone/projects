/**
 * @constant Maximum 32-bit unsigned integet value (2^32 - 1)
 */
define(function(){
    return 4294967295;
});
