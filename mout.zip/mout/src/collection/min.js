define(['./make_', '../array/min', '../object/min'], function (make, arrMin, objMin) {

    /**
     * Get minimum value inside collection.
     */
    return make(arrMin, objMin);

});
