define(['./make_', '../array/some', '../object/some'], function (make, arrSome, objSome) {

    /**
     */
    return make(arrSome, objSome);

});
