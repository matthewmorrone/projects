define(['./make_', '../array/reduce', '../object/reduce'], function (make, arrReduce, objReduce) {

    /**
     */
    return make(arrReduce, objReduce);

});
