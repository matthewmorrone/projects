define(['./make_', '../array/forEach', '../object/forOwn'], function (make, arrForEach, objForEach) {

    /**
     */
    return make(arrForEach, objForEach);

});
